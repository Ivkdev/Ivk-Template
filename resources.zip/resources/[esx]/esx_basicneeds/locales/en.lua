Locales['en'] = {
  ['used_bread'] = 'you have used ~y~1x~s~ ~b~bread~s~',
  ['used_water'] = 'you have used ~y~1x~s~ ~b~water~s~',
}