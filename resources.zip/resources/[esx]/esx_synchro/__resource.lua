

-- Client Base Scripts
client_script "synchro.lua"

server_script "synchroserver.lua"
