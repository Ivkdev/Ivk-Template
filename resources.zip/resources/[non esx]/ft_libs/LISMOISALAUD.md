# ft_libs

### Prerequisites

Nothing

### Installing

Put the folder where you want it and add it to the server.cfg file :

Example:

```
start ft_libs
```

or put in to dependencies in __resource.lua :

```
dependency 'ft_libs'

or

dependencies {
  ...
  'ft_libs',
  ...
}

```

### Documentation

[Online](https://fivemtools-libs.readme.io/v1.2/)

## License

This project is licensed under the GNU General Public License v3.0 - see the [LICENSE](LICENSE) file for details

## Contributors :

- LH-Lawliet
- THEJean-Kevin
- izio38
