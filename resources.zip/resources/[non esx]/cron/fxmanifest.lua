fx_version 'adamant'

game 'gta5'

description 'cron'

version '1.0.0'

server_script 'server/main.lua'
