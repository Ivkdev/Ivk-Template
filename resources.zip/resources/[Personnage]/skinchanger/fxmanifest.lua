fx_version 'adamant'

game 'gta5'

description 'Skin Changer'

version '1.0.3'

client_scripts {
	'locale.lua',
	'locales/fr.lua',
	'config.lua',
	'client/main.lua'
}
