vehicle_generator "airtug" { -1044.51, -2749.42, 21.36, heading = 328.8 }

spawnpoint 'a_m_y_hipster_01' { x = -1044.51, y = -2749.42, z = 21.36 }